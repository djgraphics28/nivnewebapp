<?php

namespace App\Http\Livewire;

use Livewire\Component;

class StaffStockReturn extends Component
{
    
    public function render()
    {
        return view('livewire.staff-stock-return');
    }
}
