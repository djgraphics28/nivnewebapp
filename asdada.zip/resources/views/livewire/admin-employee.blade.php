<div>
    {{-- Knowing others is intelligence; knowing yourself is true wisdom. --}}
</div>
