

<?php $__env->startSection('title','Staff Dashboard'); ?>

<?php $__env->startSection('css-top'); ?>
     <!-- Ionicons -->
     <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
     <!-- Tempusdominus Bootstrap 4 -->
     <link rel="stylesheet" href="<?php echo e(asset('plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Dashboard</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{ route('admin.dashboard') }}">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
  <?php $__env->startSection('js-bot'); ?>

    <script src="<?php echo e(asset('admin/plugins/chart.js/Chart.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/dist/js/demo.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/dist/js/pages/dashboard3.js')); ?>"></script>
  <?php $__env->stopSection(); ?>
  <!-- Main content -->
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('staff-dashboard')->html();
} elseif ($_instance->childHasBeenRendered('FZmPg3O')) {
    $componentId = $_instance->getRenderedChildComponentId('FZmPg3O');
    $componentTag = $_instance->getRenderedChildComponentTagName('FZmPg3O');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FZmPg3O');
} else {
    $response = \Livewire\Livewire::mount('staff-dashboard');
    $html = $response->html();
    $_instance->logRenderedChild('FZmPg3O', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('staff.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROJECTS\nivnewebapp\resources\views/staff/dashboard.blade.php ENDPATH**/ ?>