<div>
    <!-- Main content -->
   <div class="content">
       <div class="container-fluid">
       <div class="row">
           <div class="col-lg-12">
               <div class="card card-primary card-outline">
                   <div class="card-header">
                  <button wire:click.prevent="add()" class="btn btn-primary float-right"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add New Tracking</button>
                   </div>
                   <div class="card-body">
                       <?php if(session()->has('message')): ?>
                           <div class="alert alert-success">
                               <?php echo e(session('message')); ?>

                           </div>
                       <?php endif; ?>
                        <div class="form-group">
                            <input wire:model.prevent="searchTerm" type="text" class="col-md-6 form-control float-right mb-1" placeholder="Search here">
                        </div>
                        <div class="table-responsive">

                            <h6 class="card-title">Tracking Datatables</h6>

                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Tracking No.</th>
                                        <th>Salesman</th>
                                        <th>Vehicle</th>
                                        <th>Total Products</th>
                                        <th>Total Items Load</th>
                                        <th>Total Items Return</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $productouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($data->tracking_number); ?></td>
                                            <td><?php echo e($data->employee->firstname ." ". $data->employee->lastname); ?></td>
                                            <td><?php echo e($data->vehicle); ?></td>
                                            <td><?php echo e($data->product_tracking_count); ?></td>
                                            <td><?php echo e($data->product_tracking_sum_qty); ?></td>
                                            <td><?php echo e($data->product_tracking_sum_return_qty); ?></td>
                                            <td>
                                                <button class="btn btn-success btn-sm" wire:click.prevent="addProduct(<?php echo e($data->id); ?>)"> <i class="fa fa-plus" aria-hidden="true"></i> Load</button>
                                                <button class="btn btn-danger btn-sm" wire:click.prevent="stockReturn(<?php echo e($data->id); ?>)"> Return</button>
                                                
                                                <a href="/staff/generate-delivery-receipt/<?php echo e($data->id); ?>" class="btn btn-primary btn-sm"><i class="fa fa-print" aria-hidden="true"></i></a>
                                                <button class="btn btn-warning btn-sm" wire:click.prevent="edit(<?php echo e($data->id); ?>)"> <i class="fa fa-edit" aria-hidden="true"></i></button>
                                                <button class="btn btn-danger btn-sm" wire:click.prevent="confirmation(<?php echo e($data->id); ?>)"> <i class="fa fa-trash" aria-hidden="true"></i></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td class="center" colspan="6">No Record found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Tracking No.</th>
                                        <th>Salesman</th>
                                        <th>Vehicle</th>
                                        <th>Total Products</th>
                                        <th>Total Items Load</th>
                                        <th>Total Items Return</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                            </table>


                        </div>
               </div>
           </div>
           <!-- /.col-md-6 -->
       </div>
       <!-- /.row -->
       </div><!-- /.container-fluid -->
   </div>
   <!-- /.content -->

  

   <!-- Form Modal -->
   <div class="modal fade" id="formModal" tabindex="-1" role="dialog" aria-labelledby="formModalLabel" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog" role="document">
    <form action="" wire:submit.prevent="submit">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="formModalLabel">Add New Tracking</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>

        </div>
        <div class="modal-body">
                 <div class="form-group">
                     <label for="">Vehicle</label>
                     <select wire:model.defer="vehicle" class="form-control <?php $__errorArgs = ['vehicle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="select2bs4">
                          <option value="">Choose</option>
                          <option value="Truck 1">Truck 1</option>
                          <option value="Truck 2">Truck 2</option>
                          <option value="Van 1">Van 1</option>
                          <option value="Van 2">Van 2</option>
                      </select>
                      <?php $__errorArgs = ['vehicle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                 <div class="form-group">
                    <label for="">Salesman</label>
                        <select class="form-control <?php $__errorArgs = ['salesman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer="salesman">
                            <option value="">Choose</option>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>"><?php echo e($data->firstname. " "  .$data->lastname); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      <?php $__errorArgs = ['salesman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                 <div class="form-group">
                     <label for="">Date</label>
                    <input type="date" wire:model.defer="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                      <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>

         

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal" wire:click.prevent="cancel">Cancel</button>
            <?php if($updateMode == true): ?>
                <button wire:click.prevent="update" class="btn btn-success">Update</button>
            <?php else: ?>
                <button wire:click.prevent="submit" class="btn btn-primary">Save</button>
            <?php endif; ?>

        </div>

    </div>
    </form>
    </div>
</div>

   <!-- Return Modal -->
   <div class="modal fade" id="returnModal" tabindex="-1" role="dialog" aria-labelledby="returnModalLabel" aria-hidden="true" wire:ignore.self>
       <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="returnModalLabel">Return Stocks</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    
                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>ProductName</th>
                                    <th>Description</th>
                                    <th>Unit</th>
                                    <th>No. of Items Return</th>
                                    <th>No. in Pieces</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->product->product_name); ?></td>
                                        <td><?php echo e($item->product->description); ?></td>
                                        <td><?php echo e($item->return_unit); ?></td>
                                        <td><?php echo e($item->return_qty ." ".$item->return_unit."(s)"); ?></td>
                                        <td><?php echo e($item->pieces_qty ." pcs"); ?></td>
                                        <td>
                                            <button class="btn btn-warning btn-sm" wire:click.prevent="enterReturnQty(<?php echo e($item->id); ?>)"> <i class="fa fa-edit" aria-hidden="true"></i></button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
       </div>
   </div>

   <!-- Confirmation Modal -->
   <div class="modal fade" id="confirmationModaltracking" tabindex="-1" role="dialog" aria-labelledby="confirmationModalLabel" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="confirmationModalLabel">Delete Tracking</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <h3>Are you sure you want to delete this?</h3>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                    <button wire:click.prevent="delete()" type="button" class="btn btn-danger">Yes, Delete it.</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
  <!-- Form Modal -->
  <div class="modal fade" id="returnQty" tabindex="-1" role="dialog" aria-labelledby="returnQtyLabel" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog" role="document">
    <form action="" wire:submit.prevent="submitReturnQty">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="formModalLabel">Return Stocks</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>

        </div>
        <div class="modal-body">
            <div class="form-group">
                <label for="">Unit</label>
               <select wire:model.defer="return_unit" class="form-control <?php $__errorArgs = ['return_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                   <option value="">Choose</option>
                   <option value="BOX">BOX</option>
                   <option value="CASE">CASE</option>
                   <option value="PIECE">PIECE</option>
               </select>
                <?php $__errorArgs = ['return_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="">Enter Quantity <span>(<?php echo e($return_unit); ?>)</span></label>
                <input type="number" wire:model.defer="return_qty" class="form-control <?php $__errorArgs = ['return_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['return_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="">Enter Quantity (pieces)</label>
                <input type="number" wire:model.defer="pieces_qty" class="form-control <?php $__errorArgs = ['pieces_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['pieces_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="">Enter Return Date</label>
                <input type="date" wire:model.defer="date_return" class="form-control <?php $__errorArgs = ['date_return'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['date_return'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal" wire:click.prevent="cancel">Cancel</button>

            <button wire:click.prevent="submitReturnQty" class="btn btn-primary">Save</button>


        </div>

    </div>
    </form>
    </div>
</div>


</div>
</div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('staff-stock-add-product-to-tracking')->html();
} elseif ($_instance->childHasBeenRendered('l394617297-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l394617297-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l394617297-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l394617297-0');
} else {
    $response = \Livewire\Livewire::mount('staff-stock-add-product-to-tracking');
    $html = $response->html();
    $_instance->logRenderedChild('l394617297-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH D:\WEB PROJECTS\nivnewebapp\resources\views/livewire/staff-stock-productout.blade.php ENDPATH**/ ?>