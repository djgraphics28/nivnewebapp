<div>
     <!-- Main content -->
   <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card card-primary card-outline">
                        <div class="card-header">
                            <button wire:click.prevent="add()" class="btn btn-primary float-right"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add New Tracking</button>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="">Start</label>
                                    <input type="date" class="form-control">
                                </div>
                                <div class="col-md-3">
                                    <label for="">End</label>
                                    <input type="date" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label for="">Search Tracking Number here</label>
                                    <input wire:model.prevent="searchTerm" type="text" class="form-control" placeholder="Search Tracking Number here">
                                </div>
                            </div>
                            <br>
                            <div class="table-responsive">
                                <h6 class="card-title">Trucking Datatables</h6>
                                    <table class="table table-bordered table-hover table-sm">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>#</th>
                                                <th>Tracking Number</th>
                                                <th>Date of Tracking</th>
                                                <th>Salesman</th>
                                                <th>Vehicle</th>
                                                <th></th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $truckinventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($data->tracking_number); ?></td>
                                                    <td><?php echo e($data->date_load); ?></td>
                                                    <td><?php echo e($data->employee->firstname); ?></td>
                                                    <td><?php echo e($data->vehicle); ?></td>
                                                    <td>
                                                        <table class="table table-sm table-condensed table-striped">
                                                            <thead>
                                                                <tr>
                                                                    <th>Date Load</th>
                                                                    <th>No. of Items Load</th>
                                                                    <th>Date Return</th>
                                                                    <th>No. of Items Return</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>

                                                            <?php $__currentLoopData = $data->tracking_dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><button wire:click.prevent="showItems(<?php echo e($item->id); ?>)" title="click here to show list of items" class="btn btn-primary"><?php echo e($item->date_load); ?></td>
                                                                    <td></td>
                                                                    <td><button title="click here to show list of items" <?php echo e($item->date_return ? '' : 'disabled'); ?> class="btn btn-warning"><?php echo e($item->date_return ?  $item->date_return : '0000-00-00'); ?></td>
                                                                    <td></td>
                                                                    <td>
                                                                        <button title="Edit Items" class="btn btn-warning btn-sm" wire:click.prevent="edit(<?php echo e($item->id); ?>)"> <i class="fas fa-edit"></i></button>
                                                                        <button title="Delete Items" class="btn btn-danger btn-sm" wire:click.prevent="alertConfirm(<?php echo e($item->id); ?>)"> <i class="fas fa-trash"></i></button>
                                                                    </td>

                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </table>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-success" wire:click.prevent="addNewLoading(<?php echo e($data->id); ?>)"> Add</button>
                                                        <button class="btn btn-warning" wire:click.prevent="edit(<?php echo e($data->id); ?>)"> Edit</button>
                                                        <button class="btn btn-danger" wire:click.prevent="confirmation(<?php echo e($data->id); ?>)"> Delete</button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="7"><center>No Record Found</center></td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                        <tfoot class="table-dark">
                                            <tr>
                                                <th>#</th>
                                                <th>Tracking Number</th>
                                                <th>Date of Tracking</th>
                                                <th>Salesman</th>
                                                <th>Vehicle</th>
                                                <th></th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>

                            <?php echo e($truckinventories->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
            <!-- /.col-md-6 -->
        </div>
    <!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content -->

<!-- Tracking Modal -->
<div class="modal fade" id="TrackingModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="trackingModalLabel">Tracking</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Vehicle</label>
                        <select wire:model.defer="vehicle" class="form-control <?php $__errorArgs = ['vehicle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="select2bs4">
                             <option value="">Choose</option>
                             <option value="Truck 1">Truck 1</option>
                             <option value="Truck 2">Truck 2</option>
                             <option value="Van 1">Van 1</option>
                             <option value="Van 2">Van 2</option>
                         </select>
                         <?php $__errorArgs = ['vehicle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <span class="invalid-feedback" role="alert">
                                 <strong><?php echo e($message); ?></strong>
                             </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Salesman</label>
                            <select class="form-control <?php $__errorArgs = ['salesman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer="salesman">
                                <option value="">Choose</option>
                                <?php $__currentLoopData = $salesmans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->firstname. " "  .$data->lastname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          <?php $__errorArgs = ['salesman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($message); ?></strong>
                              </span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Date</label>
                       <input type="date" wire:model.defer="date_load" class="form-control <?php $__errorArgs = ['date_load'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                         <?php $__errorArgs = ['date_load'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <span class="invalid-feedback" role="alert">
                                 <strong><?php echo e($message); ?></strong>
                             </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <hr>

                <table class="table table-condensed table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>ProductName</th>
                            <th>Quantity</th>
                            
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <select class="form-control"  wire:model="product_id.<?php echo e($value); ?>">
                                    <option value="">-- choose ---</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->product_name." - ".$product->description ." - UNIT > (".$product->unit.") "); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td>
                                <input type="number" wire:model="quantity.<?php echo e($value); ?>" class="form-control">
                            </td>
                            
                            <td>
                                <button class="btn btn-danger" wire:click.prevent="removeItem(<?php echo e($key); ?>)">Remove</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <hr>
                <button class="btn btn-success" wire:click.prevent="addItem(<?php echo e($i); ?>)">Add Product</button>
                <hr>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" wire:click.prevent="submit()">Save changes</button>
        </div>
      </div>
    </div>
</div>



<!-- Tracking Modal -->
<div class="modal fade" id="itemsTrackingModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="trackingModalLabel">Items for Tracking No.: <?php echo e($tracking_number." | Date Load: ". $tracking_date ." | Salesman: ". $salesman); ?></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover table-condensed">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Product</th>
                            <th>Description</th>
                            <th>Unit</th>
                            <th>Quantity</th>
                            <th>Price/Case</th>
                            <th>Price/Piece</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $truckItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->products->product_name); ?></td>
                                <td><?php echo e($item->products->description); ?></td>
                                <td><?php echo e($item->products->unit); ?></td>
                                <td><?php echo e($item->load_quantity); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" wire:click.prevent="submit()">Save changes</button>
        </div>
      </div>
    </div>
</div>

<!-- add new loading Modal -->
<div class="modal fade" id="addNewLoadingModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="trackingModalLabel">Add new Loading for Tracking No.: <?php echo e($tracking_number." | Salesman: ". $salesman); ?></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="form-group">
                <label for="">Date</label>
               <input type="date" wire:model.defer="date_load" class="form-control <?php $__errorArgs = ['date_load'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                 <?php $__errorArgs = ['date_load'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <span class="invalid-feedback" role="alert">
                         <strong><?php echo e($message); ?></strong>
                     </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="row">
            <hr>

                <table class="table table-condensed table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>ProductName</th>
                            <th>Quantity</th>
                            
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <select class="form-control"  wire:model="product_id.<?php echo e($value); ?>">
                                    <option value="">-- choose ---</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->product_name." - ".$product->description ." - UNIT > (".$product->unit.") "); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td>
                                <input type="number" wire:model="quantity.<?php echo e($value); ?>" class="form-control">
                            </td>
                            
                            <td>
                                <button class="btn btn-danger" wire:click.prevent="removeItem(<?php echo e($key); ?>)">Remove</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <hr>
                <button class="btn btn-success" wire:click.prevent="addItem(<?php echo e($i); ?>)">Add Product</button>
                <hr>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" wire:click.prevent="saveNewItemsToTracking()">Save changes</button>
        </div>
      </div>
    </div>
</div>

</div>
<?php /**PATH D:\WEB PROJECTS\nivnewebapp\resources\views/livewire/staff-truck-inventory.blade.php ENDPATH**/ ?>