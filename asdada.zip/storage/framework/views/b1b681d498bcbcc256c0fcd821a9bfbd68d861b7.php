

<?php $__env->startSection('title','Staff Product In'); ?>

<?php $__env->startSection('css-top'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Truck Loading/Return</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('staff.dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('staff.stocks')); ?>">Stocks</a></li>
            <li class="breadcrumb-item active">Truck Loading/Return</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

<?php $__env->startSection('js-bot'); ?>
  <script>
      //add stock Modal
        window.addEventListener('show-product_tracking-modal', event => {
            $('#productTrackingModal').modal('show');
        })

        window.addEventListener('hide-product_tracking-modal', event => {
            $('#productTrackingModal').modal('hide');
        })



        //add equipment Modal
        window.addEventListener('show-add-equipment-modal', event => {
            $('#addEquipmentModal').modal('show');
        })

        window.addEventListener('hide-add-equipment-modal', event => {
            $('#addEquipmentModal').modal('hide');
        })

        //view stock Modal
        window.addEventListener('show-view-stock-modal', event => {
            $('#viewStockModal').modal('show');
        })

        window.addEventListener('hide-view-stock-modal', event => {
            $('#viewStockModal').modal('hide');
        })

        window.addEventListener('swal:modal', event => {
            swal({
                title: event.detail.message,
                text: event.detail.text,
                icon: event.detail.type,
            });
        });

        window.addEventListener('swal:confirm', event => {
            swal({
                    title: event.detail.message,
                    text: event.detail.text,
                    icon: event.detail.type,
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        window.livewire.emit('remove');
                    }
            });
        });
  </script>
<?php $__env->stopSection(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('staff-stock-productout')->html();
} elseif ($_instance->childHasBeenRendered('EFmdqZR')) {
    $componentId = $_instance->getRenderedChildComponentId('EFmdqZR');
    $componentTag = $_instance->getRenderedChildComponentTagName('EFmdqZR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EFmdqZR');
} else {
    $response = \Livewire\Livewire::mount('staff-stock-productout');
    $html = $response->html();
    $_instance->logRenderedChild('EFmdqZR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('staff.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROJECTS\nivnewebapp\resources\views/staff/stocks/productout.blade.php ENDPATH**/ ?>