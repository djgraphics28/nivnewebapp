<?php $__env->startSection('title','Staff Receipts'); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Receipts</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('staff.dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item active">Receipts</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <?php $__env->startSection('js-bot'); ?>
  <script>
      //add stock Modal
        window.addEventListener('show-add-product-receipt-modal', event => {
            $('#productReceiptModal').modal('show');
        })

        window.addEventListener('hide-add-product-receipt-modal', event => {
            $('#productReceiptModal').modal('hide');
        })

        window.addEventListener('show-receipt_product-modal', event => {
            $('#receiptProductEditModal').modal('show');
        })

        window.addEventListener('hide-receipt_product-modal', event => {
            $('#receiptProductEditModal').modal('hide');
        })

        window.addEventListener('show-add-receipt-modal', event => {
            $('#addReceiptModal').modal('show');
        })

        window.addEventListener('hide-add-receipt-modal', event => {
            $('#addReceiptModal').modal('hide');
        })

        //add equipment Modal
        window.addEventListener('show-edit-receipt-modal', event => {
            $('#editReceiptModal').modal('show');
        })

        window.addEventListener('hide-edit-receipt-modal', event => {
            $('#editReceiptModal').modal('hide');
        })

        //view stock Modal
        window.addEventListener('show-edit-items-receipt-modal', event => {
            $('#editItemsReceiptModal').modal('show');
        })

        window.addEventListener('hide-edit-items-receipt-modal', event => {
            $('#editItemsReceiptModal').modal('hide');
        })

        window.addEventListener('swal:modal', event => {
            swal({
                title: event.detail.message,
                text: event.detail.text,
                icon: event.detail.type,
            });
        });

        window.addEventListener('swal:confirm', event => {
            swal({
                    title: event.detail.message,
                    text: event.detail.text,
                    icon: event.detail.type,
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        window.livewire.emit('remove');
                    }
            });
        });
  </script>
<?php $__env->stopSection(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('staff-receipt')->html();
} elseif ($_instance->childHasBeenRendered('S1cvC4z')) {
    $componentId = $_instance->getRenderedChildComponentId('S1cvC4z');
    $componentTag = $_instance->getRenderedChildComponentTagName('S1cvC4z');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('S1cvC4z');
} else {
    $response = \Livewire\Livewire::mount('staff-receipt');
    $html = $response->html();
    $_instance->logRenderedChild('S1cvC4z', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('staff.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROJECTS\nivnewebapp\resources\views/staff/receipts/index.blade.php ENDPATH**/ ?>