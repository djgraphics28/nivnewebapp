

<?php $__env->startSection('title','Staff Product In'); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Product In</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('staff.dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('staff.stocks')); ?>">Stocks</a></li>
            <li class="breadcrumb-item active">Product In</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('staff-stock-productin')->html();
} elseif ($_instance->childHasBeenRendered('pjIktUo')) {
    $componentId = $_instance->getRenderedChildComponentId('pjIktUo');
    $componentTag = $_instance->getRenderedChildComponentTagName('pjIktUo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pjIktUo');
} else {
    $response = \Livewire\Livewire::mount('staff-stock-productin');
    $html = $response->html();
    $_instance->logRenderedChild('pjIktUo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('staff.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROJECTS\nivnewebapp\resources\views/staff/stocks/productin.blade.php ENDPATH**/ ?>