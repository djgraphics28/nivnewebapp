<div>
    <div class="content">
        <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-primary card-outline">
                    <div class="card-header">
                   <button wire:click.prevent="addNew()" class="btn btn-primary float-right"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Products</button>
                    </div>
                    <div class="card-body">

                            <div class="form-group">
                                <input wire:model.prevent="searchTerm" type="text" class="col-md-6 form-control float-right mb-1" placeholder="Search here">
                            </div>
                            <div class="table-responsive">
                            <h6 class="card-title">Product Lists</h6>
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                         <th>#</th>
                                         <th>ProductName</th>
                                         <th>Description</th>
                                         <th>Brand</th>
                                         <th>Category</th>
                                         <th>Stocks</th>
                                         <th>LowStockNumber</th>
                                         <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $supplier_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $product->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($prod->product_name); ?></td>
                                                <td><?php echo e($prod->description); ?></td>
                                                <td><?php echo e($prod->brand->brand_name); ?></td>
                                                <td><?php echo e($prod->category->category_name); ?></td>
                                                <td><?php echo e($prod->stocks); ?></td>
                                                <td><?php echo e($prod->stockalert); ?></td>
                                                <td>
                                                    <button class="btn btn-warning" wire:click.prevent="edit(<?php echo e($prod->id); ?>)"> Edit</button>
                                                    <button class="btn btn-danger" wire:click.prevent="confirmation(<?php echo e($prod->id); ?>)"> Delete</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="8"><center>No Record Found</center></td>
                                            </tr>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>ProductName</th>
                                        <th>Description</th>
                                        <th>Brand</th>
                                        <th>Category</th>
                                        <th>Stocks</th>
                                        <th>LowStockNumber</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                            </table>

                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>


     <!-- Add Receipt Modal -->
     <div class="modal fade" id="addSupplierProductModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Add Products</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <table class="table table-condensed table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Product</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $inputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <select class="form-control <?php $__errorArgs = ['product_id.'.$value];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  wire:model="product_id.<?php echo e($value); ?>">
                                    <option value="">-- choose ---</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->product_name." - ".$product->description ." - UNIT > (".$product->unit.") "); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['product_id.'.$value];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                                <button class="btn btn-danger" wire:click.prevent="removeItem(<?php echo e($key); ?>)">Remove</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <hr>
                <button class="btn btn-success" wire:click.prevent="addItem(<?php echo e($i); ?>)">Add Product</button>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" wire:click.prevent="submit()" class="btn btn-primary">Save changes</button>
            </div>
        </div>
        </div>
    </div>
   <!-- Modal -->
</div>
<?php /**PATH D:\WEB PROJECTS\nivnewebapp\resources\views/livewire/staff-supplier-product.blade.php ENDPATH**/ ?>