<?php $__env->startSection('title','Staff Suppliers Products'); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Suppliers/Products</h1>
          <h3><?php echo e($supplier); ?></h3>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('staff.dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('staff.suppliers')); ?>">Suppliers</a></li>
            <li class="breadcrumb-item active">Suppliers/Products</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <?php $__env->startSection('js-bot'); ?>
  <script>
      //add stock Modal
        window.addEventListener('show-add-supplier-product-modal', event => {
            $('#addSupplierProductModal').modal('show');
        })

        window.addEventListener('hide-add-supplier-product-modal', event => {
            $('#addSupplierProductModal').modal('hide');
        })

        window.addEventListener('swal:modal', event => {
            swal({
                title: event.detail.message,
                text: event.detail.text,
                icon: event.detail.type,
            });
        });

        window.addEventListener('swal:confirm', event => {
            swal({
                    title: event.detail.message,
                    text: event.detail.text,
                    icon: event.detail.type,
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        window.livewire.emit('remove');
                    }
            });
        });
  </script>
<?php $__env->stopSection(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('staff-supplier-product', ['supplier_id' => $supplier_id])->html();
} elseif ($_instance->childHasBeenRendered('pbh7iWg')) {
    $componentId = $_instance->getRenderedChildComponentId('pbh7iWg');
    $componentTag = $_instance->getRenderedChildComponentTagName('pbh7iWg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pbh7iWg');
} else {
    $response = \Livewire\Livewire::mount('staff-supplier-product', ['supplier_id' => $supplier_id]);
    $html = $response->html();
    $_instance->logRenderedChild('pbh7iWg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('staff.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROJECTS\nivnewebapp\resources\views/staff/suppliers/product.blade.php ENDPATH**/ ?>