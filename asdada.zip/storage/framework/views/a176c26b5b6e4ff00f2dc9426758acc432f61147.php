<nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
      <!-- Add icons to the links using the .nav-icon class
           with font-awesome or any other icon font library -->
      
      <li class="nav-item">
        <a href="<?php echo e(route('staff.dashboard')); ?>" class="nav-link <?php echo e(request()->is('staff/dashboard') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-tachometer-alt"></i>
          <p>
            Dashboard
            <?php if(Auth::user()->branch_id == 2): ?>
                <span class="right badge badge-danger">New</span>
            <?php endif; ?>

          </p>
        </a>
      </li>
      
       <li class="nav-item">
        <a href="<?php echo e(route('staff.customers')); ?>" class="nav-link <?php echo e(request()->is('staff/customers') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-users"></i>
          <p>Customers</p>
        </a>
      </li>
      <li class="nav-item">
        <a href="<?php echo e(route('staff.brands')); ?>" class="nav-link <?php echo e(request()->is('staff/brands') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-cogs"></i>
          <p>Brands</p>
        </a>
      </li>
      <li class="nav-item">
        <a href="<?php echo e(route('staff.categories')); ?>" class="nav-link <?php echo e(request()->is('staff/categories') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-cogs"></i>
          <p>Categories</p>
        </a>
      </li>
      <li class="nav-item">
        <a href="<?php echo e(route('staff.suppliers')); ?>" class="nav-link <?php echo e(request()->is('staff/suppliers') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-users"></i>
          <p>Suppliers</p>
        </a>
      </li>
      <li class="nav-item">
        <a href="<?php echo e(route('staff.products')); ?>" class="nav-link <?php echo e(request()->is('staff/products') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-cogs"></i>
          <p>Products</p>
        </a>
      </li>

      <li class="nav-item">
        <a href="<?php echo e(route('staff.truckinventories')); ?>" class="nav-link <?php echo e(request()->is('staff/truckinventories') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-truck"></i>
          <p>Truck Inventory</p>
        </a>
      </li>
      

      <li class="nav-item <?php echo e(strpos(Request::url(), 'reports') == true ? 'menu-open' : ''); ?>">
        <a href="#" class="nav-link <?php echo e(strpos(Request::url(), 'reports') == true ? 'active' : ''); ?>">
          <i class="nav-icon fas fa-boxes"></i>
          <p>
            Reports
            <i class="right fas fa-angle-left"></i>
          </p>
        </a>
        <ul class="nav nav-treeview">
          <li class="nav-item">
             <a href="#" class="nav-link <?php echo e(request()->is('staff/reports/sales') ? 'active' : ''); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Sales Report</p>
             </a>
          </li>

        </ul>
      </li>

      <li class="nav-item">
        <a href="<?php echo e(route('staff.employees')); ?>" class="nav-link <?php echo e(request()->is('staff/employees') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-users"></i>
          <p>Employees</p>
        </a>
      </li>
      <li class="nav-item">
        <a href="<?php echo e(route('staff.receipts')); ?>" class="nav-link <?php echo e(request()->is('staff/receipts') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-money-check"></i>
          <p>Receipts</p>
        </a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="nav-icon fas fa-sign-out-alt"></i>
            <p><?php echo e(__('Logout')); ?></p>
        </a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
      </li>
    </ul>
  </nav>
<?php /**PATH D:\WEB PROJECTS\nivnewebapp\resources\views/staff/layouts/sidebar.blade.php ENDPATH**/ ?>