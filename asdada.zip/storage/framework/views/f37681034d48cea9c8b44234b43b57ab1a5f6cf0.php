<?php $__env->startSection('title','Staff Products'); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Products</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('staff.dashboard')); ?>">Home</a></li>
            <li class="breadcrumb-item active">Products</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <?php $__env->startSection('js-bot'); ?>
  <script>
      //add stock Modal
        window.addEventListener('show-add-new_stock-modal', event => {
            $('#addNewStockmodal').modal('show');
        })

        window.addEventListener('hide-add-new_stock-modal', event => {
            $('#addNewStockmodal').modal('hide');
        })

        window.addEventListener('show-set-price-modal', event => {
            $('#setPriceModal').modal('show');
        })

        window.addEventListener('hide-set-price-modal', event => {
            $('#setPriceModal').modal('hide');
        })


        window.addEventListener('swal:modal', event => {
            swal({
                title: event.detail.message,
                text: event.detail.text,
                icon: event.detail.type,
            });
        });

        window.addEventListener('swal:confirm', event => {
            swal({
                    title: event.detail.message,
                    text: event.detail.text,
                    icon: event.detail.type,
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        window.livewire.emit('remove');
                    }
            });
        });
  </script>
<?php $__env->stopSection(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('staff-product')->html();
} elseif ($_instance->childHasBeenRendered('8WwonuV')) {
    $componentId = $_instance->getRenderedChildComponentId('8WwonuV');
    $componentTag = $_instance->getRenderedChildComponentTagName('8WwonuV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8WwonuV');
} else {
    $response = \Livewire\Livewire::mount('staff-product');
    $html = $response->html();
    $_instance->logRenderedChild('8WwonuV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('staff.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROJECTS\nivnewebapp\resources\views/staff/products/index.blade.php ENDPATH**/ ?>